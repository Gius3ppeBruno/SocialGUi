module SocialV3 {
	requires java.desktop;
}