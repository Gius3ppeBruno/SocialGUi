package socialGUI;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.SwingConstants;

public class Main_GUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private int usedSocial = -1;
	private JTextField CreateNickname;
	private JTextField FindNickname;
	private ImageIcon imageIcon;
	private Image image;
	ImageIcon resizedImageIcon;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main_GUI frame = new Main_GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};

	/**
	 * Create the frame.
	 */
	public Main_GUI() {
		setTitle("Social Manager");
		setResizable(false);
		
		ArrayList<Social> socials = new ArrayList<>();
		//Social predefiniti
		socials.add(new Social("Facebook", "Facebook è una piattaforma di social networking che ti consente di connetterti e condividere con amici e familiari.", 2004, 0));
		socials.add(new Social("Instagram", "Instagram è un'applicazione di social media che consente agli utenti di condividere foto e video, e di interagire con altri utenti tramite like, commenti e messaggi.", 2010, 0));
		socials.add(new Social("Twitter", "Twitter è una piattaforma di social media che consente agli utenti di condividere brevi messaggi di testo, chiamati tweet, con i propri follower.", 2006, 0));
		
		//Stampa informazioni social presenti		
		MainMethods.LoadInfoSocial(socials); //da eseguire solo 1 volta all'inizio
        
		//funzione utilizzabile solo in socialCL
        //System.out.println("7. Rimuovi tutti gli account dal social.");
        
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setEditable(false);
		textArea.setBounds(137, 10, 289, 80);
		//textArea.setText("Lorem Ipsum è un testo segnaposto utilizzato nel settore della tipografia e della stampa. Lorem Ipsum è considerato il testo segnaposto standard sin dal sedicesimo secolo, quando un anonimo tipografo prese una cassetta di caratteri e li assemblò per preparare un testo campione. È sopravvissuto non solo a più di cinque secoli, ma anche al passaggio alla videoimpaginazione, pervenendoci sostanzialmente inalterato. Fu reso popolare, negli anni ’60, con la diffusione dei fogli di caratteri trasferibili “Letraset”, che contenevano passaggi del Lorem Ipsum, e più recentemente da software di impaginazione come Aldus PageMaker, che includeva versioni del Lorem Ipsum.");
		JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBounds(160, 10, 266, 55);
        
		contentPane.add(scrollPane);
		
		JLabel InUseSocialName = new JLabel("");
		InUseSocialName.setBounds(306, 70, 120, 20);
		contentPane.add(InUseSocialName);		
		
		// Caricamento dell'immagine da file
		imageIcon = new ImageIcon(getClass().getResource("images/NotFound.png"));
        // Ridimensionamento dell'immagine per adattarla al JLabel
        image = imageIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        // Creazione di un nuovo ImageIcon con l'immagine ridimensionata
        resizedImageIcon = new ImageIcon(image);
        JLabel SocialLogo = new JLabel(resizedImageIcon);
        SocialLogo.setHorizontalAlignment(SwingConstants.LEFT);
        SocialLogo.setBackground(new Color(0, 0, 0));
        SocialLogo.setText("Logo");
        SocialLogo.setSize(50, 50);
        SocialLogo.setLocation(45, 40);
        contentPane.add(SocialLogo);
        
		JComboBox<String> dropdown = new JComboBox<>();
		dropdown.addItem("Scegli Social");
        for (Social social : socials) {
            dropdown.addItem(social.getName());
        }
        dropdown.setBounds(10, 10, 120, 20);
		
        // Aggiunta ActionListener al JComboBox
        dropdown.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Azioni da eseguire quando un elemento viene selezionato
                String selectedSocial = (String) dropdown.getSelectedItem();
                System.out.println("Elemento selezionato: " + selectedSocial);
                // Esegui qui le azioni desiderate in base all'elemento selezionato
                usedSocial = dropdown.getSelectedIndex() - 1;
                if(usedSocial < 0) {
                	InUseSocialName.setText("In uso: " + dropdown.getSelectedItem());
                	// Simulazione di un cambiamento della path dell'immagine
			        // Questa riga modifica la path dell'immagine a "nuova_path.png"
			        imageIcon = new ImageIcon(getClass().getResource("images/NotFound.png"));
			        // Ridimensionamento dell'immagine per adattarla al JLabel
			        image = imageIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
			        // Creazione di un nuovo ImageIcon con l'immagine ridimensionata
			        resizedImageIcon = new ImageIcon(image);
			        // Impostazione della nuova immagine nel JLabel
			        SocialLogo.setIcon(resizedImageIcon);
                }else {
                	try {
                	    InUseSocialName.setText("In uso: " + socials.get(usedSocial).getName());
                	    String selectedSocial1 = socials.get(usedSocial).getName();
                	    if("Twitter".equals(selectedSocial1)) {
                	        imageIcon = new ImageIcon(getClass().getResource("images/twitter.png"));
                	    } else if("Facebook".equals(selectedSocial1)) {
                	        imageIcon = new ImageIcon(getClass().getResource("images/facebook.png"));
                	    } else if("Instagram".equals(selectedSocial1)) {
                	        imageIcon = new ImageIcon(getClass().getResource("images/instagram.png"));
                	    } else {
                	        throw new IllegalArgumentException("Social non supportato: " + selectedSocial1);
                	    }
                	    image = imageIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
                	    resizedImageIcon = new ImageIcon(image);
                	    SocialLogo.setIcon(resizedImageIcon);
                	} catch(Exception ImageNotFound) {
                	    System.out.println("Logo non trovato per: " + socials.get(usedSocial).getName());
                	    InUseSocialName.setText("In uso: " + socials.get(usedSocial).getName());
                	    imageIcon = new ImageIcon(getClass().getResource("images/NotFound.png"));
                	    image = imageIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
                	    resizedImageIcon = new ImageIcon(image);
                	    SocialLogo.setIcon(resizedImageIcon);
                	}}}}
                
        );
        
        contentPane.add(dropdown);
		
		JButton infoSocial = new JButton("Info Social");
		infoSocial.setBackground(new Color(192, 192, 192));
		infoSocial.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(usedSocial < 0 || usedSocial > socials.size()) {
						throw MainExceptions.noSelectedSocial();
					}
					textArea.setText(socials.get(usedSocial).toString());
				}catch(MainExceptions Social) {
					System.out.println(Social.getMessage());
					textArea.setText(Social.getMessage());
				}
			}
		});
		infoSocial.setBounds(160, 70, 120, 20);
		contentPane.add(infoSocial);
		
		JButton btnInfluencersECreators = new JButton("Influencers e Creators");
		btnInfluencersECreators.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(usedSocial < 0 || usedSocial > socials.size()) {
						throw MainExceptions.noSelectedSocial();
					}
				textArea.setText(socials.get(usedSocial).countInfluencersAndCreators());
				}catch(MainExceptions Social) {
					System.out.println(Social.getMessage());
					textArea.setText(Social.getMessage());
				}
			}
		});
		btnInfluencersECreators.setBounds(10, 100, 170, 25);
		contentPane.add(btnInfluencersECreators);
		
		JButton mediaPost = new JButton("Media post");
		mediaPost.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(usedSocial < 0 || usedSocial > socials.size()) {
						throw MainExceptions.noSelectedSocial();
					}
				textArea.setText(socials.get(usedSocial).averagePostsPerUser());
				}catch(MainExceptions Social) {
					System.out.println(Social.getMessage());
					textArea.setText(Social.getMessage());
				}
			}
		});
		mediaPost.setBounds(190, 100, 100, 25);
		contentPane.add(mediaPost);
		
		JButton mostFollowedUser = new JButton("Top user");
		mostFollowedUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(usedSocial < 0 || usedSocial > socials.size()) {
						throw MainExceptions.noSelectedSocial();
					}
				textArea.setText(socials.get(usedSocial).accountWithMostFollowers());
				}catch(MainExceptions Social) {
					System.out.println(Social.getMessage());
					textArea.setText(Social.getMessage());
				}
			}
		});
		mostFollowedUser.setBounds(300, 100, 126, 25);
		contentPane.add(mostFollowedUser);
		
		
		JLabel Nickname1 = new JLabel("Nickname");
		Nickname1.setBounds(10, 135, 416, 13);
		contentPane.add(Nickname1);
		
		CreateNickname = new JTextField();
		CreateNickname.setBounds(10, 150, 256, 20);
		contentPane.add(CreateNickname);
		CreateNickname.setColumns(10);
		
		JButton CreateAcc = new JButton("Crea Account");
		CreateAcc.setBackground(new Color(0, 255, 128));
		CreateAcc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(usedSocial < 0 || usedSocial > socials.size()) {
						throw MainExceptions.noSelectedSocial();
					}
				textArea.setText(MainMethods.addAccount(socials.get(usedSocial), CreateNickname.getText()));
				}catch(MainExceptions Social) {
					System.out.println(Social.getMessage());
					textArea.setText(Social.getMessage());
				}
			}
		});
		CreateAcc.setBounds(280, 150, 150, 20);
		contentPane.add(CreateAcc);
		
		
		JLabel Nickname2 = new JLabel("Nickname");
		Nickname2.setBounds(10, 170, 416, 13);
		contentPane.add(Nickname2);
		
		FindNickname = new JTextField();
		FindNickname.setColumns(10);
		FindNickname.setBounds(10, 185, 256, 20);
		contentPane.add(FindNickname);
		
		JButton FindAcc = new JButton("Trova Account");
		FindAcc.setBackground(new Color(0, 255, 255));
		FindAcc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(usedSocial < 0 || usedSocial > socials.size()) {
						throw MainExceptions.noSelectedSocial();
					}
					textArea.setText(socials.get(usedSocial).accountExists(FindNickname.getText()));
				}catch(MainExceptions Social) {
					System.out.println(Social.getMessage());
					textArea.setText(Social.getMessage());
				}
			}
		});
		FindAcc.setBounds(280, 185, 150, 20);
		contentPane.add(FindAcc);
		
		JLabel GroupInfo = new JLabel("Progetto Gruppo 1: Bruno G. - Buonocore R. - Caseraro G. - Trezza P. ");
		GroupInfo.setHorizontalAlignment(SwingConstants.CENTER);
		GroupInfo.setBounds(10, 240, 416, 20);
		contentPane.add(GroupInfo);

	}
}
