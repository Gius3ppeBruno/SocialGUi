package socialCLI;

public class MainExceptions extends Exception {

	public MainExceptions() {
		super("Errore.");
	}

	public MainExceptions(String messaggio) {
		super(messaggio);
	}

	public static MainExceptions noAccounts() {
		return new MainExceptions("Non ci sono account su questo social.");
	}
	
	public static MainExceptions noSelectedSocial() {
		return new MainExceptions("Scegliere prima il social network.");
	}
}
