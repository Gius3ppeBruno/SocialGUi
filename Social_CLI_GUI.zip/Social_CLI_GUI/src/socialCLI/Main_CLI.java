package socialCLI;

import java.util.ArrayList;
import java.util.Scanner;

public class Main_CLI{

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		//ArrayList di social
		ArrayList<Social> socials = new ArrayList<>();
		//Social predefiniti
		socials.add(new Social("Facebook", "Facebook è una piattaforma di social networking che ti consente di connetterti e condividere con amici e familiari.", 2004, 0));
		socials.add(new Social("Instagram", "Instagram è un'applicazione di social media che consente agli utenti di condividere foto e video, e di interagire con altri utenti tramite like, commenti e messaggi.", 2010, 0));
		socials.add(new Social("Twitter", "Twitter è una piattaforma di social media che consente agli utenti di condividere brevi messaggi di testo, chiamati tweet, con i propri follower.", 2006, 0));
		//Stampa informazioni social presenti		
		MainMethods.LoadInfoSocial(socials); //da eseguire solo 1 volta all'inizio
		
        int usedSocial = -1;
        int choice = -1;
        
		while(true) {
			System.out.println("\n---- MENU ----");
            System.out.println("1. Utilizza un social network");
            System.out.println("2. Aggiungere un account a un social network");
            System.out.println("3. Informazioni social");
            System.out.println("4. Visualizza numero influencer e creator del social.");
            System.out.println("5. Numero di post medi social.");
            System.out.println("6. Account con più follower.");
            System.out.println("7. Rimuovi tutti gli account dal social.");
            System.out.println("8. Cerca un account nel social.");
            System.out.println("0. Uscire");
            System.out.println("---- FINE MENU ----\n");
            
            choice = MainMethods.sceltaMenu(choice);
            
            try {               
            switch (choice) {
	            case 0: 
	                System.out.println("Uscita..."); // Uscita dal programma
	                System.out.flush();
	                System.exit(0);
	                break;
	            case 1:
	            	usedSocial = MainMethods.useSocialNetwork(socials);
	            	break;
	            case 2: 
	        		MainMethods.addAccount(socials.get(usedSocial));
                    break;
	            case 3: 
	            	MainMethods.showCurrentSocial(socials.get(usedSocial));
	            	break;
	            case 4: 
	            	socials.get(usedSocial).countInfluencersAndCreators();
	            	break;
	            case 5:
	            	socials.get(usedSocial).averagePostsPerUser();
	            	break;
	            case 6:
	            	socials.get(usedSocial).accountWithMostFollowers();
	            	break;
	            case 7:	
	            	socials.get(usedSocial).clearFileAndArray("src/socialCLI/" + socials.get(usedSocial).getName() + ".txt", socials.get(usedSocial).getAccounts());
	            	break;
	            case 8:
	            	socials.get(usedSocial).accountExists();
	            	break;
	            default:
                    System.out.println("Azione non supportata.");
                    break;      
            }
            }catch(MainExceptions e) {
            	System.out.println(e.getMessage());
            }catch(Exception e) {
            	System.out.println("Assicurati di aver scelto correttamente il Social.");
            }
		}
	}
}
