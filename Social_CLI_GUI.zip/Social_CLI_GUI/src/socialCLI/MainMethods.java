package socialCLI;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class MainMethods{
	
    public static void LoadInfoSocial(ArrayList<Social> socials) {
		System.out.println("Social esistenti: ");
		for(Social social : socials) {
			//stampa social senza caricare account registrati
			//System.out.println(social);
			
			//stampa dopo aver caricato gli account registrati
			//readAccountsFromFile deve essere usato solo all'inizio, perchè crea Account nell'ArrayList basandosi solo sul file, quindi può duplicarli
			social.readAccountsFromFile("src/socialCLI/" + social.getName() + ".txt");
			social.setRegisteredAccount(social.getNumAccounts());
			System.out.println(social);
			
			//ArrayList<Account> socialAccounts = social.getAccounts();
			//Stampa info
	        //for (Account account : socialAccounts) {
	        //	System.out.println(account.toString());
	        //}
	        //System.out.println(""); //Spaziatura
		}
	}
    
	public static void stampaSocial(ArrayList<Social> socials) {
		int i = 1;
		for(Social social : socials) {
			//stampa nomi social senza ricaricare account registrati
			System.out.println(i + ". " + social.getName());
			i++;
		}
	}
	
	public static int sceltaMenu(int choice) {
        do {
            try {
            	System.out.print("Scegli azione: ");
    	        choice = input.nextInt(); // Lettura della scelta dell'utente
    	        input.nextLine(); // Consuma il newline
            }catch(Exception e) {
            	choice = -1;
            	input.nextLine();
            }
        }while(choice == -1);
        
		return choice;
	}
	
	public static boolean isNicknameExists(Social social, String nickname) {
		ArrayList<Account> socialAccounts = social.getAccounts();
		//Stampa info
        for (Account account : socialAccounts) {      	
        	if(account.getNickname().equals(nickname)) {
        		System.out.println("Nickname già presente nel file.");
        		return true;
        	}
        }
		return false;
	}
	
	public static void showCurrentSocial(Social social) {
		System.out.println(social);
	}
	
	public static Scanner input = new Scanner(System.in);
	
	public static int useSocialNetwork(ArrayList<Social> socials) {
		int usedSocial = -1;
		do {
        	System.out.println("Seleziona il social da utilizzare");
        	MainMethods.stampaSocial(socials);
    	    try {
    	        usedSocial = MainMethods.input.nextInt() - 1; //seleziona l'indice corretto di ArrayList   
    	    } catch (Exception e) {
    	    	System.out.println("Input non valido: riprova.");
    	        usedSocial = -1; // Reinizializza la variabile
    	        input.next(); // consuma il newline
    	    }
    	} while (usedSocial < 0 || usedSocial >= socials.size());
		
		System.out.println("Social selezionato: " + socials.get(usedSocial).getName());		
		return usedSocial;
	}
	
	public static void addAccount(Social social) {
        
		System.out.println("Inserisci il nickname: ");
		String nickname = input.nextLine();
		
        // Controlla se il nickname esiste già nel file
        if (MainMethods.isNicknameExists(social, nickname)) {     
            return;
        }
        
        // Generazione casuale dei followers, seguiti e post
        int followerCount = 0;
        int followingCount = 0;
        try {
            followerCount = MainMethods.random.nextInt(social.getRegisteredAccount());
            followingCount = MainMethods.random.nextInt(social.getRegisteredAccount());
        }catch(Exception e) {
        	System.out.println("Noacc: ");
        	followerCount = 0;
        	followingCount = 0;
        }
        int postCount = MainMethods.random.nextInt(3000);
        
        String filename = "src/socialCLI/" + social.getName() + ".txt";
        
        MainMethods.writeUserDataToFile(filename, nickname, followerCount, followingCount, postCount);
        social.sortFileLinesByFirstIntAndRewrite(filename);
        social.addAccountToArraylist(new Account(nickname, followerCount, followingCount, postCount));
        social.sortByFollowersDescending();
        
        social.setRegisteredAccount(social.getNumAccounts());
	}
	
	public static final Random random = new Random();
	
	// Metodo per scrivere le informazioni dell'account nel file per un dato social network
    public static void writeUserDataToFile(String filename, String nickname, int followerCount, int followingCount, int postCount) {
        try (FileWriter fw = new FileWriter(filename, true)) {
            fw.write(nickname + ", " + followerCount + ", " + followingCount + ", " + postCount + "\n");
            System.out.println("Account aggiunto al file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
